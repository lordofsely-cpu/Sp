package com.sely.assistant.engine

/**
 * Classifies a raw utterance and, where possible, resolves it directly into one or more
 * [ActionStep]s using reusable patterns — not a lookup table of exact phrases. New phrasings
 * of the same intent ("open Chrome" / "launch Chrome" / "take me to Chrome") fall out of the
 * same pattern instead of needing their own entry.
 */
object CommandRouter {

    private val webRequestWords = listOf(
        "search the web", "search online", "google ", "look up online", "browse the web",
        "find online", "latest news", "current news"
    )

    private val aiQuestionStarters = listOf(
        "what ", "why ", "how ", "who ", "when ", "where ", "explain", "define", "describe",
        "translate", "write ", "code ", "debug", "summarize", "compare", "difference between",
        "help me understand", "can you explain"
    )

    private val localTaskWords = listOf(
        "remind me", "reminder", "set an alarm", "set a timer", "note", "routine",
        "device info", "battery", "storage space", "how much storage"
    )

    private val phoneActionPatterns: List<Regex> = listOf(
        Regex("\\b(open|launch|start|go to|take me to)\\b"),
        Regex("\\b(scroll|swipe|tap|click|long press)\\b"),
        Regex("\\b(volume|flashlight|torch|brightness)\\b"),
        Regex("\\b(screenshot|take a screenshot)\\b"),
        Regex("\\b(lock|go home|go back|recent apps|recents)\\b"),
        Regex("\\bopen settings\\b")
    )

    fun classify(text: String): RequestType {
        val t = text.lowercase().trim()
        if (t.isEmpty()) return RequestType.UNKNOWN

        val isPhoneAction = phoneActionPatterns.any { it.containsMatchIn(t) }
        val isWeb = webRequestWords.any { t.contains(it) }
        val isLocalTask = localTaskWords.any { t.contains(it) }
        val isAiQuestion = aiQuestionStarters.any { t.startsWith(it) || t.contains(" $it") } || t.endsWith("?")

        return when {
            isPhoneAction && (isWeb || isAiQuestion) -> RequestType.MIXED_TASK
            isWeb -> RequestType.WEB_REQUEST
            isPhoneAction -> RequestType.PHONE_ACTION
            isLocalTask -> RequestType.LOCAL_TASK
            isAiQuestion -> RequestType.AI_REQUEST
            else -> RequestType.UNKNOWN
        }
    }

    /** Splits a compound instruction into ordered sub-instructions ("open X and search for Y"). */
    fun splitMultiStep(text: String): List<String> {
        return text.split(Regex("\\b(and then|then|,\\s*and|,)\\b"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }
    }

    /**
     * Normalizes common natural-language synonyms onto a canonical verb the rest of Sely's
     * pattern matching already understands, so new phrasings don't need new hard-coded commands.
     */
    fun normalizeSynonyms(text: String): String {
        var t = " ${text.lowercase().trim()} "
        val replacements = listOf(
            Regex("\\b(launch|start|take me to|go to|fire up)\\b") to "open",
            Regex("\\b(move down|go further down|scroll further down)\\b") to "scroll down",
            Regex("\\b(move up|go further up|scroll further up)\\b") to "scroll up",
            Regex("\\b(turn on the flashlight|switch on the flashlight|torch on)\\b") to "turn on flashlight",
            Regex("\\b(turn off the flashlight|switch off the flashlight|torch off)\\b") to "turn off flashlight",
            Regex("\\b(lock the phone|lock my screen)\\b") to "lock my phone",
            Regex("\\b(go back home|return home)\\b") to "go home",
            Regex("\\b(press back|navigate back)\\b") to "go back",
            Regex("\\b(open recent apps|show recent apps|open app switcher)\\b") to "open recents",
            Regex("\\b(turn the volume up|raise the volume)\\b") to "volume up",
            Regex("\\b(turn the volume down|lower the volume)\\b") to "volume down",
            Regex("\\b(take a screenshot|capture the screen|capture my screen)\\b") to "take screenshot",
            Regex("\\b(stop that|cancel that|never mind|nevermind)\\b") to "stop"
        )
        replacements.forEach { (pattern, canonical) -> t = pattern.replace(t) { " $canonical " } }
        return t.trim()
    }

    /**
     * Best-effort resolution of the newer whitelisted actions (navigation, accessibility
     * gestures, volume/brightness/media, screenshots, info queries) into an [ActionStep].
     * Legacy commands already handled by SelyCommandProcessor's own matching take priority and
     * never reach here — this only covers the actions added for the Action Engine.
     */
    fun toActionStep(rawText: String): ActionStep? {
        val t = normalizeSynonyms(rawText)

        return when {
            t == "go home" -> ActionStep(ActionType.GO_HOME)
            t == "go back" -> ActionStep(ActionType.GO_BACK)
            t == "open recents" -> ActionStep(ActionType.OPEN_RECENTS)
            t == "scroll down" -> ActionStep(ActionType.SCROLL_DOWN)
            t == "scroll up" -> ActionStep(ActionType.SCROLL_UP)
            t.startsWith("swipe ") -> ActionStep(ActionType.SWIPE, t.removePrefix("swipe ").trim())
            t.startsWith("tap ") -> ActionStep(ActionType.TAP, t.removePrefix("tap ").trim())
            t.startsWith("long press ") -> ActionStep(ActionType.LONG_PRESS, t.removePrefix("long press ").trim())
            t.startsWith("type ") -> ActionStep(ActionType.TYPE_TEXT, t.removePrefix("type ").trim())
            t == "clear text" || t == "clear the text field" -> ActionStep(ActionType.CLEAR_TEXT)
            t == "press enter" -> ActionStep(ActionType.PRESS_ENTER)
            t == "read the screen" || t == "read screen" || t == "what's on screen" || t == "what is on the screen" ->
                ActionStep(ActionType.READ_SCREEN)
            t == "take screenshot" -> ActionStep(ActionType.TAKE_SCREENSHOT)
            t == "volume up" -> ActionStep(ActionType.CONTROL_VOLUME, "up")
            t == "volume down" -> ActionStep(ActionType.CONTROL_VOLUME, "down")
            t == "mute" || t == "mute volume" -> ActionStep(ActionType.CONTROL_VOLUME, "mute")
            t == "unmute" -> ActionStep(ActionType.CONTROL_VOLUME, "unmute")
            t == "play" || t == "resume music" || t == "pause music" || t == "pause" ->
                ActionStep(ActionType.CONTROL_MEDIA, "play_pause")
            t == "next song" || t == "skip song" -> ActionStep(ActionType.CONTROL_MEDIA, "next")
            t == "previous song" -> ActionStep(ActionType.CONTROL_MEDIA, "previous")
            t == "brightness up" -> ActionStep(ActionType.CONTROL_BRIGHTNESS, "up")
            t == "brightness down" -> ActionStep(ActionType.CONTROL_BRIGHTNESS, "down")
            t == "device info" || t == "what's my device" || t == "what phone is this" -> ActionStep(ActionType.DEVICE_INFO)
            t == "battery" || t == "battery info" || t == "battery level" || t == "how much battery" ->
                ActionStep(ActionType.BATTERY_INFO)
            t == "storage info" || t == "how much storage" || t == "storage space" -> ActionStep(ActionType.STORAGE_INFO)
            t.startsWith("open settings") && t.contains(" for ") -> ActionStep(ActionType.OPEN_SETTINGS_PAGE, t.substringAfter(" for ").trim())
            t == "open settings" -> ActionStep(ActionType.OPEN_SETTINGS)
            t == "stop" || t == "cancel" -> ActionStep(ActionType.STOP_TASK)
            t == "pause" -> ActionStep(ActionType.PAUSE_TASK)
            else -> null
        }
    }
}
