package com.sely.assistant.engine

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.AlarmClock
import android.provider.Settings
import android.view.KeyEvent
import com.sely.assistant.SelyAccessibilityService

/**
 * Executes a single [ActionStep]. This is the one place in Sely that is allowed to actually
 * move the device — the Command Router and any AI output only ever produce [ActionStep]s from
 * the [ActionType] whitelist; nothing else can reach here.
 *
 * Every call returns an [ActionResult] describing what really happened. Callers must not
 * report success to the user unless [ActionResult.success] is true — see SelyCommandProcessor's
 * ACTION -> OBSERVE -> VERIFY usage.
 */
class ActionEngine(private val context: Context) {

    private val accessibility: SelyAccessibilityService?
        get() = SelyAccessibilityService.instance

    fun execute(step: ActionStep): ActionResult {
        if (TaskMemory.stopRequested && step.type != ActionType.STOP_TASK) {
            return ActionResult(false, "Cancelled — you asked me to stop.")
        }
        val result = when (step.type) {
            ActionType.OPEN_APP -> openApp(step.target)
            ActionType.GO_HOME -> globalOrFail { it.goHome() }
            ActionType.GO_BACK -> globalOrFail { it.goBack() }
            ActionType.OPEN_RECENTS -> globalOrFail { it.openRecents() }
            ActionType.TAP -> accessibilityOrFail { it.tapByText(step.target) }
            ActionType.LONG_PRESS -> accessibilityOrFail { it.longPressByText(step.target) }
            ActionType.SWIPE -> accessibilityOrFail { it.swipe(step.target) }
            ActionType.SCROLL_UP -> accessibilityOrFail { it.scroll("up") }
            ActionType.SCROLL_DOWN -> accessibilityOrFail { it.scroll("down") }
            ActionType.TYPE_TEXT -> accessibilityOrFail { it.typeIntoFocused(step.target) }
            ActionType.CLEAR_TEXT -> accessibilityOrFail { it.clearFocusedText() }
            ActionType.PRESS_ENTER -> accessibilityOrFail { it.pressEnter() }
            ActionType.SEARCH -> search(step.target)
            ActionType.SELECT -> accessibilityOrFail { it.tapByText(step.target) }
            ActionType.COPY -> copyToClipboard(step.target)
            ActionType.PASTE -> pasteFromClipboard()
            ActionType.WAIT -> waitMs(step.target)
            ActionType.READ_SCREEN -> readScreen()
            ActionType.TAKE_SCREENSHOT -> globalOrFail { it.takeScreenshot() }
            ActionType.OPEN_URL -> openUrl(step.target)
            ActionType.OPEN_SETTINGS -> openSettings(null)
            ActionType.OPEN_SETTINGS_PAGE -> openSettings(step.target)
            ActionType.CONTROL_VOLUME -> controlVolume(step.target)
            ActionType.CONTROL_MEDIA -> controlMedia(step.target)
            ActionType.CONTROL_FLASHLIGHT -> controlFlashlight(step.target)
            ActionType.CONTROL_BRIGHTNESS -> controlBrightness(step.target)
            ActionType.SET_ALARM -> setAlarm(step.target)
            ActionType.SET_TIMER -> setTimer(step.target)
            ActionType.DEVICE_INFO -> deviceInfo()
            ActionType.BATTERY_INFO -> batteryInfo()
            ActionType.STORAGE_INFO -> storageInfo()
            ActionType.RUN_ROUTINE -> ActionResult(false, "Routines are replayed by SelyCommandProcessor, not the Action Engine directly.")
            ActionType.CREATE_ROUTINE -> ActionResult(false, "Say \"create a routine called <name> that does <steps>\" to save one.")
            ActionType.SHARE_CONTENT -> shareContent(step.target)
            ActionType.STOP_TASK, ActionType.PAUSE_TASK -> { TaskMemory.requestStop(); ActionResult(true, "Stopped.") }
            ActionType.AI_REQUEST, ActionType.WEB_SEARCH, ActionType.UNKNOWN ->
                ActionResult(false, "That's not a device action the Action Engine handles.")
        }
        TaskMemory.recordAction(step, result)
        return result
    }

    // ---- Accessibility-backed actions ----

    private fun accessibilityOrFail(block: (SelyAccessibilityService) -> Boolean): ActionResult {
        val svc = accessibility
            ?: return ActionResult(false, "Accessibility Service is off. Enable it in Sely's Permission Center to allow this.")
        return if (block(svc)) ActionResult(true, "Done.") else ActionResult(false, "I couldn't find or perform that on the current screen.")
    }

    private fun globalOrFail(block: (SelyAccessibilityService) -> Boolean): ActionResult {
        val svc = accessibility
            ?: return ActionResult(false, "Accessibility Service is off. Enable it in Sely's Permission Center to allow this.")
        return if (block(svc)) ActionResult(true, "Done.") else ActionResult(false, "That action isn't supported on this device/Android version.")
    }

    private fun readScreen(): ActionResult {
        val svc = accessibility
            ?: return ActionResult(false, "Accessibility Service is off, so I can't read the screen right now.")
        val text = svc.readScreenText()
        return if (text.isBlank()) ActionResult(false, "I couldn't find any readable text on this screen.")
        else ActionResult(true, text)
    }

    private fun search(query: String): ActionResult {
        val svc = accessibility ?: return ActionResult(false, "Accessibility Service is off, so I can't type into this app.")
        if (query.isBlank()) return ActionResult(false, "I don't have a search term to use.")
        val typed = svc.typeIntoFocused(query)
        if (!typed) return ActionResult(false, "I couldn't find a text field to search in.")
        TaskMemory.recordSearch(query)
        svc.pressEnter()
        return ActionResult(true, "Searching for $query.")
    }

    // ---- App launching ----

    private fun openApp(appName: String): ActionResult {
        if (appName.isBlank()) return ActionResult(false, "Which app would you like me to open?")
        val pm = context.packageManager
        val installed = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val needle = appName.trim().lowercase()
        val match = installed.firstOrNull { pm.getApplicationLabel(it).toString().lowercase().contains(needle) }
            ?: installed.firstOrNull { needle.contains(pm.getApplicationLabel(it).toString().lowercase()) }
        if (match == null) return ActionResult(false, "I couldn't find an app called $appName.")
        val launchIntent = pm.getLaunchIntentForPackage(match.packageName)
            ?: return ActionResult(false, "$appName can't be launched directly.")
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launchIntent)
        val label = pm.getApplicationLabel(match).toString()
        TaskMemory.recordAppOpened(label)
        return ActionResult(true, "$label is open.")
    }

    // ---- Clipboard ----

    private fun copyToClipboard(text: String): ActionResult {
        if (text.isBlank()) return ActionResult(false, "There's nothing to copy.")
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("sely", text))
        return ActionResult(true, "Copied.")
    }

    private fun pasteFromClipboard(): ActionResult {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        if (clip == null || clip.itemCount == 0) return ActionResult(false, "Clipboard is empty.")
        val text = clip.getItemAt(0).coerceToText(context).toString()
        val svc = accessibility ?: return ActionResult(false, "Accessibility Service is off, so I can't paste into this app.")
        return if (svc.typeIntoFocused(text)) ActionResult(true, "Pasted.") else ActionResult(false, "I couldn't find a text field to paste into.")
    }

    // ---- Misc waits ----

    private fun waitMs(millisText: String): ActionResult {
        val ms = millisText.toLongOrNull()?.coerceIn(0, 3000) ?: 500
        Thread.sleep(ms) // only ever called off the main thread by the task runner
        return ActionResult(true, "Waited.")
    }

    // ---- URLs / settings ----

    private fun openUrl(url: String): ActionResult {
        if (url.isBlank()) return ActionResult(false, "I don't have a URL to open.")
        val fixedUrl = if (url.startsWith("http")) url else "https://$url"
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(fixedUrl)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            ActionResult(true, "Opening $fixedUrl.")
        } catch (e: Exception) {
            ActionResult(false, "I couldn't open that link.")
        }
    }

    private fun openSettings(page: String?): ActionResult {
        val action = when (page?.lowercase()?.trim()) {
            null, "" -> Settings.ACTION_SETTINGS
            "wifi", "wi-fi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "apps", "applications" -> Settings.ACTION_APPLICATION_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            "date", "time" -> Settings.ACTION_DATE_SETTINGS
            "security" -> Settings.ACTION_SECURITY_SETTINGS
            "notifications" -> Settings.ACTION_APP_NOTIFICATION_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return try {
            context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            ActionResult(true, "Opening settings.")
        } catch (e: Exception) {
            ActionResult(false, "That settings page isn't available on this device.")
        }
    }

    // ---- Volume / media / flashlight / brightness ----

    private fun controlVolume(direction: String): ActionResult {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val stream = AudioManager.STREAM_MUSIC
        return when (direction.lowercase()) {
            "up" -> { am.adjustStreamVolume(stream, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); ActionResult(true, "Volume up.") }
            "down" -> { am.adjustStreamVolume(stream, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); ActionResult(true, "Volume down.") }
            "mute" -> { am.adjustStreamVolume(stream, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); ActionResult(true, "Muted.") }
            "unmute" -> { am.adjustStreamVolume(stream, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI); ActionResult(true, "Unmuted.") }
            else -> ActionResult(false, "Say volume up, down, mute, or unmute.")
        }
    }

    private fun controlMedia(action: String): ActionResult {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val keyCode = when (action.lowercase()) {
            "play", "pause", "play_pause", "toggle" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous", "back" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> return ActionResult(false, "Say play, pause, next, or previous.")
        }
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
        return ActionResult(true, "Done.")
    }

    private fun controlFlashlight(state: String): ActionResult {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList.firstOrNull {
                cameraManager.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return ActionResult(false, "This device doesn't have a flashlight.")
            val turnOn = state.lowercase() != "off"
            cameraManager.setTorchMode(cameraId, turnOn)
            ActionResult(true, if (turnOn) "Flashlight on." else "Flashlight off.")
        } catch (e: Exception) {
            ActionResult(false, "I couldn't control the flashlight.")
        }
    }

    private fun controlBrightness(direction: String): ActionResult {
        if (!Settings.System.canWrite(context)) {
            return try {
                val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                ActionResult(false, "I need the \"Modify system settings\" permission to control brightness — please allow it, then try again.", requiresConfirmation = true)
            } catch (e: Exception) {
                ActionResult(false, "I can't control brightness on this device.")
            }
        }
        val resolver = context.contentResolver
        val current = Settings.System.getInt(resolver, Settings.System.SCREEN_BRIGHTNESS, 128)
        val step = 40
        val newValue = when (direction.lowercase()) {
            "up" -> (current + step).coerceAtMost(255)
            "down" -> (current - step).coerceAtLeast(10)
            else -> return ActionResult(false, "Say brightness up or down.")
        }
        Settings.System.putInt(resolver, Settings.System.SCREEN_BRIGHTNESS, newValue)
        return ActionResult(true, "Brightness ${direction.lowercase()}.")
    }

    // ---- Alarms / timers (official AlarmClock intents — no custom parsing needed) ----

    private fun setAlarm(spec: String): ActionResult {
        return try {
            val parts = spec.split(":")
            val hour = parts.getOrNull(0)?.trim()?.toIntOrNull()
            val minute = parts.getOrNull(1)?.trim()?.toIntOrNull() ?: 0
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                if (hour != null) {
                    putExtra(AlarmClock.EXTRA_HOUR, hour)
                    putExtra(AlarmClock.EXTRA_MINUTES, minute)
                }
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ActionResult(true, "Alarm set.")
        } catch (e: Exception) {
            ActionResult(false, "I couldn't set that alarm.")
        }
    }

    private fun setTimer(secondsText: String): ActionResult {
        val seconds = secondsText.toIntOrNull() ?: return ActionResult(false, "How many seconds should the timer run for?")
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ActionResult(true, "Timer started.")
        } catch (e: Exception) {
            ActionResult(false, "I couldn't start that timer.")
        }
    }

    // ---- Device / battery / storage info ----

    private fun deviceInfo(): ActionResult {
        val info = "${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
        return ActionResult(true, info)
    }

    private fun batteryInfo(): ActionResult {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        return ActionResult(true, "Battery is at $pct%${if (charging) ", charging" else ""}.")
    }

    private fun storageInfo(): ActionResult {
        val stat = StatFs(Environment.getDataDirectory().path)
        val totalGb = stat.blockCountLong * stat.blockSizeLong / (1024.0 * 1024.0 * 1024.0)
        val freeGb = stat.availableBlocksLong * stat.blockSizeLong / (1024.0 * 1024.0 * 1024.0)
        return ActionResult(true, "%.1f GB free of %.1f GB.".format(freeGb, totalGb))
    }

    // ---- Sharing ----

    private fun shareContent(text: String): ActionResult {
        if (text.isBlank()) return ActionResult(false, "There's nothing to share.")
        return try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Share via").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            ActionResult(true, "Opening the share sheet.")
        } catch (e: Exception) {
            ActionResult(false, "I couldn't open the share sheet.")
        }
    }
}
