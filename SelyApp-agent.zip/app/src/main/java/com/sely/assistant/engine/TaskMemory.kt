package com.sely.assistant.engine

/**
 * Session-only task memory (cleared on process death — this is *context*, not the durable
 * memory system in SelyCommandProcessor's "remember ..." feature). Tracks just enough state
 * for natural follow-ups to resolve correctly.
 */
object TaskMemory {
    var lastAppOpened: String? = null
        private set
    var lastSearchQuery: String? = null
        private set
    var lastAction: ActionStep? = null
        private set
    var lastActionResult: ActionResult? = null
        private set

    /** Set when Sely is waiting on a yes/no for a consequential action ("send it?"). */
    var pendingConfirmation: ActionStep? = null

    /** Flips true when the user says "stop"/"cancel"/"pause"; the executing task should check this. */
    @Volatile var stopRequested: Boolean = false

    fun recordAppOpened(appName: String) {
        lastAppOpened = appName
    }

    fun recordSearch(query: String) {
        lastSearchQuery = query
    }

    fun recordAction(step: ActionStep, result: ActionResult) {
        lastAction = step
        lastActionResult = result
    }

    fun requestStop() {
        stopRequested = true
        pendingConfirmation = null
    }

    fun clearStop() {
        stopRequested = false
    }

    fun clearConfirmation() {
        pendingConfirmation = null
    }
}
